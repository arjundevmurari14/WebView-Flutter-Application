import 'package:flutter/material.dart';
import 'webview_flutter.dart'; // Make sure this import is correct

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instagram Viewer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CustomWebView(
        initialUrl: 'https://www.instagram.com/anushkasen0408?igsh=MThnMjhhMTBheWJ3eQ==',
      ),
    );
  }
}


/*import 'package:flutter/material.dart';
import 'webview_flutter.dart';  // Ensure the import is correct

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Instagram',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CustomWebView(
        initialUrl: 'https://www.instagram.com/kritisanon?igsh=dTJuOHhuams4MzM5',
      ),
    );
  }
}*/

/*
import 'package:flutter/material.dart';
import 'webview_flutter.dart';  // Import the WebView widget

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Custom WebView App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const CustomWebView(initialUrl: 'https://flutter.dev'), // Initial URL to load
    );
  }
}*/
