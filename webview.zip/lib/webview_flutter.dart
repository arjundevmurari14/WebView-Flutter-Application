import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:flutter/scheduler.dart';

class CustomWebView extends StatefulWidget {
  final String initialUrl;

  const CustomWebView({Key? key, required this.initialUrl}) : super(key: key);

  @override
  _CustomWebViewState createState() => _CustomWebViewState();
}

class _CustomWebViewState extends State<CustomWebView>
    with WidgetsBindingObserver {
  late WebViewController _controller;
  bool isLoading = true; // Track loading state
  final List<String> _history = []; // Store browsing history

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this); // Listen to app lifecycle events

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onPageStarted: (_) => _setLoading(true),
        onPageFinished: (url) {
          _addToHistory(url);
          _setLoading(false);
        },
        onNavigationRequest: (NavigationRequest request) {
          if (request.url.contains('instagram.com')) {
            return NavigationDecision.navigate;
          }
          return NavigationDecision.prevent;
        },
      ))
      ..enableZoom(true) // Allow zooming
      ..loadRequest(Uri.parse(widget.initialUrl));
  }

  // Manage cache to prevent page reload on reopening the app
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _controller.clearCache(); // Save cache state when app goes to background
    }
  }

  void _setLoading(bool loading) {
    setState(() {
      isLoading = loading;
    });
  }

  void _addToHistory(String url) {
    if (_history.isEmpty || _history.last != url) {
      setState(() {
        _history.add(url);
      });
    }
  }

  void _clearHistory() {
    setState(() {
      _history.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Browsing history cleared!')),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this); // Cleanup observer
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        if (await _controller.canGoBack()) {
          _controller.goBack(); // Navigate back if possible
          return false;
        } else {
          return true; // Exit the app if no back history
        }
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Instagram Viewer'),
          actions: [
            if (isLoading)
              const Padding(
                padding: EdgeInsets.all(16.0),
                child: CircularProgressIndicator(color: Colors.white),
              ),
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: () => _controller.reload(),
            ),
            IconButton(
              icon: const Icon(Icons.clear_all),
              onPressed: _clearHistory,
            ),
          ],
        ),
        body: WebViewWidget(controller: _controller),
        drawer: Drawer(
          child: ListView(
            children: [
              const DrawerHeader(
                decoration: BoxDecoration(color: Colors.blue),
                child: Text(
                  'History',
                  style: TextStyle(color: Colors.white, fontSize: 24),
                ),
              ),
              ..._history.map((url) => ListTile(
                title: Text(url),
                onTap: () {
                  _controller.loadRequest(Uri.parse(url));
                  Navigator.pop(context); // Close drawer on selection
                },
              )),
            ],
          ),
        ),
      ),
    );
  }
}

/*

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class CustomWebView extends StatefulWidget {
  final String initialUrl;

  const CustomWebView({Key? key, required this.initialUrl}) : super(key: key);

  @override
  _CustomWebViewState createState() => _CustomWebViewState();
}

class _CustomWebViewState extends State<CustomWebView> {
  late WebViewController _controller;
  final List<String> _history = []; // Stores browsing history

  @override
  void initState() {
    super.initState();
    // Ensures WebView initialization
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.initialUrl))
      ..setNavigationDelegate(NavigationDelegate(
        onPageFinished: (String url) {
          _addToHistory(url); // Save visited URLs to history
        },
      ));
  }

  // Function to add URLs to history
  void _addToHistory(String url) {
    if (_history.isEmpty || _history.last != url) {
      setState(() {
        _history.add(url);
      });
    }
  }

  // Function to clear history
  void _clearHistory() {
    setState(() {
      _history.clear();
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Browsing history cleared!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Custom WebView'),
        actions: [
          IconButton(
            icon: const Icon(Icons.clear_all),
            onPressed: _clearHistory, // Clears history on click
          ),
        ],
      ),
      body: WebViewWidget(controller: _controller),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text(
                'History',
                style: TextStyle(color: Colors.white, fontSize: 24),
              ),
            ),
            ..._history.map((url) => ListTile(
              title: Text(url),
              onTap: () {
                _controller.loadRequest(Uri.parse(url));
                Navigator.pop(context); // Close drawer on selection
              },
            )),
          ],
        ),
      ),
    );
  }
}*/
