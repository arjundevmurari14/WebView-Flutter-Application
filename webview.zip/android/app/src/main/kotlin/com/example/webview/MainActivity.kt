package com.example.webview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
